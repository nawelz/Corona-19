<?php
/*
 * Plugin Name: MyThemeShop Theme Customizer
 * Plugin URI: 
 * Description: Enhances OnePage Lite theme by adding homepage sections using widgets.
 * Author: MYThemeShop
 * Author URI: https://mythemeshop.com/
 * Version: 1.0.0
 * Text Domain: mythemeshop-theme-customizer
 */

define( 'MTS_CUSTOMIZER_VERSION',  '1.0.0' );
define( 'MTS_CUSTOMIZER_PATH',  plugin_dir_path( __FILE__ ) );
define( 'MTS_CUSTOMIZER_URL',  plugin_dir_url( __FILE__ ) );

function mts_customizer_loader() {
	if ( function_exists( 'onepage_lite_setup' ) ) {
		require_once( MTS_CUSTOMIZER_PATH . 'inc/onepage-lite-functions.php' );
	}
}

add_action( 'after_setup_theme', 'mts_customizer_loader', 0 );